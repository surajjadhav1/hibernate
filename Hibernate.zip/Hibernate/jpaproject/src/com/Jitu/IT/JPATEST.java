package com.Jitu.IT;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.Jitu.model.departments;

public class JPATEST {

	
private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysqlTest");
	
	private static void saveUsingJPA(departments acc) {
		
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		
		try {
			
			entityManager = emf.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			
			entityTransaction.begin();
			
			entityManager.persist(acc);
			
			entityTransaction.commit();
			
			
		}finally {
			
			if(entityManager != null) entityManager.close();
			
		}
		
		System.out.println("Account saved successfully");
		
	}
	
	
	public static void main(String[] args) {
		
		departments account = new departments();
		account.setDeptId(7);
		account.setDeptname("Suraj");
		account.setDeptloc("Satara");

		saveUsingJPA(account);
		
		
		
	}

}
