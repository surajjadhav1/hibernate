package com.Jitu.Jdbctest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.Jitu.model.departments;

public class JDBCTEST {

	
	
public static void saveUsingJDBC(departments acc) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return;
		}

		
			
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","root");
			PreparedStatement pstmt = con.prepareStatement("insert into account values(?, ?, ?)")){
			
			System.out.println(con.getClass());
			System.out.println(pstmt.getClass());
			
			pstmt.setInt(1, acc.getDeptId());
			pstmt.setString(2, acc.getDeptname());
			pstmt.setString(3, acc.getDeptloc());
			
			
			
			pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		
		departments account = new departments();
		account.setDeptId(4);
		account.setDeptname("Jane");
		account.setDeptloc("Mumbai");

		saveUsingJDBC(account);
		
		
		
	}

}
