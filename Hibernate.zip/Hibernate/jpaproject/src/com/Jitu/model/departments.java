package com.Jitu.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class departments {

	
	@Id
	private int DeptId;
	private String Deptname;
	private String Deptloc;
	
	
	public int getDeptId() {
		return DeptId;
	}
	public void setDeptId(int deptId) {
		DeptId = deptId;
	}
	public String getDeptname() {
		return Deptname;
	}
	public void setDeptname(String deptname) {
		Deptname = deptname;
	}
	public String getDeptloc() {
		return Deptloc;
	}
	public void setDeptloc(String deptloc) {
		Deptloc = deptloc;
	}
	
	
	
	
	 
}
